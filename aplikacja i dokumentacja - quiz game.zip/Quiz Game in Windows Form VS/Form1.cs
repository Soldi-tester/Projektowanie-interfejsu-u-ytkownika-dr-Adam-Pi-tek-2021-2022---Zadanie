﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quiz_Game_in_Windows_Form_VS
{
    public partial class Form1 : Form
    {

        // zmienne

        int correctAnswer;
        int questionNumber = 1;
        int score;
        int percentage;
        int totalQuestions;
        public Form1()
        {
            InitializeComponent();

            askQuestion(questionNumber);

            totalQuestions = 8;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            // akcja kliknięcia w przycisk
        }

        private void checkAnswerEvent(object sender, EventArgs e)
        {
            var senderObject = (Button)sender;

            int buttonTag = Convert.ToInt32(senderObject.Tag);

            if(buttonTag == correctAnswer)
            {
                score++;
            }
            if(questionNumber == totalQuestions)
            {
                //jak liczona jest punktacja + zmiana na procenty

                percentage = (int)Math.Round((double)(score * 100) / totalQuestions);



                MessageBox.Show(
                    "QUIZ zakończony" + Environment.NewLine +
                    "Odpowiedziałeś na tyle pytań poprawnie = " + score + Environment.NewLine +
                    "Co łącznie daje = " + percentage + "%" + Environment.NewLine +
                    "Kliknij OK aby ponownie przejść QUIZ"
                    );

                score = 0;
                questionNumber = 0;
                askQuestion(questionNumber);
            }





            questionNumber++;
            askQuestion(questionNumber);

        }

        private void askQuestion(int qnum)
        {
            switch(qnum)
            {
                case 1:
                    pictureBox1.Image = Properties.Resources.pytanie_zwykle;
                    lblQuestion.Text = "(Pytanie rozgrzewkowe) Którą planetą od słońca jest Ziemia?";

                    button1.Text = "Trzecią";
                    button2.Text = "Czwartą";
                    button3.Text = "Drugą";
                    button4.Text = "Ziemia jest płaska!";

                    correctAnswer = 1;


                    break;

                case 2:
                    pictureBox1.Image = Properties.Resources.pytanie_zwykle;
                    lblQuestion.Text = "(Pytanie rozgrzewkowe) Alter-ego Batmana?";

                    button1.Text = "Bruce Wayne";
                    button2.Text = "Bruce Willis";
                    button3.Text = "Christian Bale";
                    button4.Text = "Ben Affleck";

                    correctAnswer = 1;


                    break;
                case 3:
                    pictureBox1.Image = Properties.Resources.godofwar;
                    lblQuestion.Text = "Jaką postać pokazano na powyższym zdjęciu?";

                    button1.Text = "Odyna";
                    button2.Text = "Marcusa";
                    button3.Text = "Max Payne'a";
                    button4.Text = "Kratosa";

                    correctAnswer = 4;


                    break;
                case 4:
                    pictureBox1.Image = Properties.Resources.dl2;
                    lblQuestion.Text = "Jakie miasto jest widoczne na powyższym zdjęciu?";

                    button1.Text = "Villedor";
                    button2.Text = "Warszawa";
                    button3.Text = "Paryż";
                    button4.Text = "Berlin";

                    correctAnswer = 1;


                    break;
                case 5:
                    pictureBox1.Image = Properties.Resources.vanguard;
                    lblQuestion.Text = "Z której części Call of Duty są ukazane na powyższym zdjęciu postacie?";

                    button1.Text = "WW2";
                    button2.Text = "Modern Warfare";
                    button3.Text = "Black Ops: Cold War";
                    button4.Text = "Vanguard";

                    correctAnswer = 4;


                    break;
                case 6:
                    pictureBox1.Image = Properties.Resources.readyornot;
                    lblQuestion.Text = "W jaką specjalną jednostkę wcielamy się w grze Ready or Not?";

                    button1.Text = "GROM";
                    button2.Text = "S.W.A.T.";
                    button3.Text = "Navy Seals";
                    button4.Text = "GIGN";

                    correctAnswer = 2;


                    break;
                case 7:
                    pictureBox1.Image = Properties.Resources.thisisthepolice2;
                    lblQuestion.Text = "W postać na jakim stanowisku wcielamy się w grze This Is The Police 2";

                    button1.Text = "Sprzedawca";
                    button2.Text = "C# Senior Developer";
                    button3.Text = "Komendant posterunku policji";
                    button4.Text = "Instruktor jazdy na nartach";

                    correctAnswer = 3;


                    break;
                case 8:
                    pictureBox1.Image = Properties.Resources.bf2042;
                    lblQuestion.Text = "W którym roku dzieją się wydarzenia w grze Battlefield 2042";

                    button1.Text = "2142";
                    button2.Text = "1942";
                    button3.Text = "2022";
                    button4.Text = "2042";

                    correctAnswer = 4;


                    break;
            }
        }
    }
}
